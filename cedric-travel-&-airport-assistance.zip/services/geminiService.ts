
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
You are a Virtual Travel Assistant for "Cedric Travel & Airport Assistance" based at Entebbe International Airport, Uganda. 

Service Pricing (approximate, subject to current rates):
- Flight Guidance: $17
- Airport Process Assistance: $32
- Airport Transfers: $27
- Planning Support: $7
- Conflict Resolution: $42
* 1 USD is approximately 3,800 UGX.

About Cedric:
- Trained Aviation Customer Service professional.
- Expert in passenger handling, airport guidance, and conflict resolution.

When answering:
- Be professional, welcoming, and helpful.
- For billing questions, you can provide the rates above but mention that a final quote is generated in the "Billing & Selection" section of the website.
- Mention contact details if requested: WhatsApp +256709733284 or Email cedriclammar256@gmail.com.
- Keep responses concise and formatted for a chat bubble.
`;

export async function getTravelAdvice(userMessage: string, history: { role: 'user' | 'model', text: string }[]) {
  try {
    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });
    
    const response = await chat.sendMessage({ message: userMessage });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having a bit of trouble connecting to my travel database. Please try again or reach out to Cedric directly via WhatsApp!";
  }
}
