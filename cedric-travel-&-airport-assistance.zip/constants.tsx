
import React from 'react';
import { ServiceCard, Testimonial } from './types';

export const COLORS = {
  primary: '#1e3a8a', // Deep Blue
  secondary: '#facc15', // Yellow
  accent: '#eab308',
  light: '#f3f4f6',
  white: '#ffffff',
};

export const SERVICES: ServiceCard[] = [
  {
    id: 'flight-guidance',
    title: 'Flight Guidance',
    description: 'Expert assistance with schedules, tickets, baggage rules, and travel prep.',
    icon: '✈️',
    priceUSD: 17, // Reduced from 25 (approx 30,000 UGX reduction)
  },
  {
    id: 'airport-process',
    title: 'Process Assistance',
    description: 'Seamless navigation through check-in, security, and boarding procedures.',
    icon: '🛂',
    priceUSD: 32, // Reduced from 40
  },
  {
    id: 'transfers',
    title: 'Airport Transfers',
    description: 'Reliable transport coordination to and from Entebbe International Airport.',
    icon: '🚗',
    priceUSD: 27, // Reduced from 35
  },
  {
    id: 'planning',
    title: 'Planning Support',
    description: 'Pre-travel documentation checklists and efficient route planning.',
    icon: '📋',
    priceUSD: 7, // Reduced from 15
  },
  {
    id: 'conflict-res',
    title: 'Conflict Resolution',
    description: 'Professional support for handling travel issues and passenger needs.',
    icon: '🤝',
    priceUSD: 42, // Reduced from 50
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    text: "Cedric helped us navigate the airport with ease — everything was smooth and professional. Highly recommend!",
    author: "Jane K.",
    rating: 5,
  },
  {
    text: "Amazing service! My family's airport transfer and check-in were seamless thanks to Cedric.",
    author: "Michael L.",
    rating: 5,
  },
  {
    text: "Professional, reliable, and friendly. I will definitely use Cedric's services again for my next trip.",
    author: "Sarah A.",
    rating: 5,
  },
];

export const EXCHANGE_RATE = 3800; // 1 USD to UGX
