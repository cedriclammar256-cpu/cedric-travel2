
export interface User {
  name: string;
  email: string;
  isLoggedIn: boolean;
}

export interface ServiceCard {
  id: string;
  title: string;
  description: string;
  icon: string;
  priceUSD: number;
}

export interface Testimonial {
  text: string;
  author: string;
  rating: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  feedback?: 'positive' | 'negative' | null;
}
