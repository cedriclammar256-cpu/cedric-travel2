
import React, { useEffect, useState, useMemo } from 'react';
import Navbar from './components/Navbar';
import Assistant from './components/Assistant';
import Auth from './components/Auth';
import { SERVICES, TESTIMONIALS, EXCHANGE_RATE } from './constants';
import { User } from './types';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [showAuth, setShowAuth] = useState(false);
  const [formStatus, setFormStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [currency, setCurrency] = useState<'USD' | 'UGX'>('USD');
  const [shouldPulse, setShouldPulse] = useState(false);
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [copyStatus, setCopyStatus] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('cedric_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }

    const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('opacity-100', 'translate-y-0');
          entry.target.classList.remove('opacity-0', 'translate-y-10');
        }
      });
    }, observerOptions);

    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    setShowAuth(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('cedric_user');
    setUser(null);
  };

  const triggerAssistant = (e: React.MouseEvent, serviceTitle: string) => {
    e.stopPropagation();
    const event = new CustomEvent('assistant-query', { 
      detail: `Tell me more about your ${serviceTitle} service and why it's beneficial for Entebbe travelers.` 
    });
    window.dispatchEvent(event);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText('+256709733284');
    setCopyStatus(true);
    setTimeout(() => setCopyStatus(false), 2000);
  };

  const toggleService = (id: string) => {
    if (!user) {
      setShowAuth(true);
      return;
    }
    setSelectedServices(prev => 
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
    setShouldPulse(true);
    setIsConfirmed(false);
    setTimeout(() => setShouldPulse(false), 400);
  };

  const billingData = useMemo(() => {
    const subtotalUSD = selectedServices.reduce((acc, id) => {
      const service = SERVICES.find(s => s.id === id);
      return acc + (service?.priceUSD || 0);
    }, 0);

    let discountPercentage = 0;
    let bundleName = '';
    
    if (selectedServices.length >= 3) {
      discountPercentage = 0.10;
      bundleName = 'Premium Bundle';
    } else if (selectedServices.length === 2) {
      discountPercentage = 0.05;
      bundleName = 'Duo Special';
    }

    const discountUSD = subtotalUSD * discountPercentage;
    const totalUSD = subtotalUSD - discountUSD;
    const rate = currency === 'USD' ? 1 : EXCHANGE_RATE;
    
    return {
      subtotal: subtotalUSD * rate,
      discount: discountUSD * rate,
      total: totalUSD * rate,
      discountPercentage: discountPercentage * 100,
      bundleName
    };
  }, [selectedServices, currency]);

  const handleConfirmSelection = () => {
    setIsConfirmed(true);
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
    setTimeout(() => setIsConfirmed(false), 5000);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) {
      setShowAuth(true);
      return;
    }
    setFormStatus('loading');
    const form = e.currentTarget;
    const data = new FormData(form);
    const serviceList = selectedServices.map(id => SERVICES.find(s => s.id === id)?.title).join(', ');
    
    const billingSummary = `
      --- BOOKING QUOTE ---
      Services: ${serviceList || 'None Selected'}
      Subtotal: ${billingData.subtotal.toLocaleString()} ${currency}
      Discount: ${billingData.discountPercentage}% (${billingData.bundleName || 'None'})
      Total: ${billingData.total.toLocaleString()} ${currency}
      Payment Method: MOBILE MONEY (MOMO)
    `;
    
    data.set('Message', `(BILLING REQUEST) User: ${user.name} (${user.email}). ${billingSummary}. User Message: ${data.get('message')}`);

    try {
      const response = await fetch(form.action, {
        method: 'POST',
        body: data,
        headers: { 'Accept': 'application/json' }
      });
      if (response.ok) {
        setFormStatus('success');
        form.reset();
        setSelectedServices([]);
        setTimeout(() => setFormStatus('idle'), 5000);
      } else {
        setFormStatus('error');
      }
    } catch (err) {
      setFormStatus('error');
    }
  };

  const renderAnimatedText = (text: string, baseDelay: number = 0) => {
    return text.split('').map((char, i) => (
      <span 
        key={i} 
        className="reveal-letter" 
        style={{ animationDelay: `${baseDelay + (i * 0.04)}s` }}
      >
        {char === ' ' ? '\u00A0' : char}
      </span>
    ));
  };

  const greeting = user ? `Hello, ${user.name.split(' ')[0]}` : 'Welcome to';
  const subGreeting = user ? 'Safe Travels' : 'The Pearl';

  return (
    <div className="min-h-screen selection:bg-yellow-200 selection:text-blue-900">
      <Navbar user={user} onAuthClick={() => setShowAuth(true)} onLogout={handleLogout} onLogoClick={scrollToTop} />

      {showAuth && <Auth onLogin={handleLogin} onClose={() => setShowAuth(false)} />}

      {/* Hero Section - Optimized Visibility */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 z-0 animate-kenburns scale-110 bg-cover bg-center"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1542296332-2e4473faf563?auto=format&fit=crop&w=1920&q=80')" }}
        />
        {/* Lighter gradient to ensure background visibility while maintaining contrast for text */}
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/60 via-transparent to-blue-900/80 z-10" />
        
        <div className="container mx-auto px-6 relative z-20 text-center text-white">
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-xl px-6 py-3 rounded-full border border-white/30 mb-8 animate-fadeIn">
            <span className="flex h-2 w-2 rounded-full bg-yellow-400 animate-pulse"></span>
            <span className="text-xs font-black uppercase tracking-[0.2em] text-white">Professional Entebbe Flight Support</span>
          </div>
          
          <h2 className="text-5xl md:text-9xl font-black mb-8 tracking-tighter leading-[0.85] drop-shadow-2xl">
            <div className="block">
              {renderAnimatedText(greeting, 0.2)}
            </div>
            <div className="block text-yellow-400 mt-4">
              {renderAnimatedText(subGreeting, 0.2 + (greeting.length * 0.04) + 0.1)}
            </div>
          </h2>

          <p className="text-xl md:text-2xl max-w-2xl mx-auto mb-12 opacity-100 animate-fadeInUp font-bold leading-relaxed [animation-delay:1.2s] fill-mode-forwards opacity-0 drop-shadow-md">
            Professional airport assistance by Cedric Musani. Certified, reliable, and dedicated to your seamless journey.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center animate-fadeInUp fill-mode-forwards opacity-0 [animation-delay:1.4s]">
            <a 
              href="#services" 
              className="bg-yellow-400 hover:bg-yellow-500 text-blue-900 font-black px-12 py-5 rounded-3xl transition-all transform hover:scale-105 active:scale-95 shadow-[0_20px_60px_rgba(250,204,21,0.4)] inline-flex items-center justify-center text-lg group"
            >
              Book Assistance
              <svg className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
            </a>
            <button 
              onClick={(e) => triggerAssistant(e, 'General Airport Support')}
              className="bg-blue-900/40 hover:bg-blue-900/60 backdrop-blur-2xl text-white border border-white/40 font-bold px-12 py-5 rounded-3xl transition-all flex items-center justify-center group text-lg"
            >
              Ask AI Assistant
              <svg className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7l5 5m0 0l-5 5m5-5H6"/></svg>
            </button>
          </div>
        </div>
      </section>

      {/* About Section - Portrait Made Visible */}
      <section id="about" className="py-40 bg-white relative overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row items-center gap-20">
            <div className="w-full lg:w-1/2 reveal opacity-0 translate-y-10 transition-all duration-1000">
              <div className="relative group cursor-pointer" onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}>
                {/* Decorative frames that frame the professional portrait */}
                <div className="absolute -inset-8 bg-blue-900 rounded-[5rem] -rotate-2 transition-transform group-hover:rotate-0 duration-700"></div>
                <div className="absolute -inset-8 border-4 border-yellow-400 rounded-[5rem] rotate-3 transition-transform group-hover:rotate-0 duration-700"></div>
                
                {/* Visual focal point - The Cedric Portrait */}
                <div className="relative aspect-[4/5] overflow-hidden rounded-[4rem] shadow-[0_40px_80px_rgba(0,0,0,0.15)] bg-slate-100">
                   <img 
                    src="https://images.unsplash.com/photo-1517733925043-473a885573a0?auto=format&fit=crop&w=1200&q=90" 
                    alt="Cedric Musani - Aviation Professional" 
                    className="w-full h-full object-cover scale-110 hover:scale-125 transition-transform duration-[2000ms] ease-out"
                  />
                  {/* Floating Identity Badge */}
                  <div className="absolute bottom-10 left-10 right-10 p-8 bg-white/90 backdrop-blur-xl rounded-[2.5rem] border border-white shadow-2xl">
                    <p className="text-blue-900 font-black text-3xl tracking-tighter">Cedric Musani</p>
                    <p className="text-blue-500 text-xs font-black uppercase tracking-[0.2em] mt-1">Skywings Certified Aviation Specialist</p>
                    <div className="flex gap-2 mt-4">
                      {[1, 2, 3].map(i => <div key={i} className="w-6 h-1 bg-yellow-400 rounded-full"></div>)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="w-full lg:w-1/2 reveal opacity-0 translate-y-10 transition-all duration-1000 delay-200">
              <div className="w-20 h-2 bg-yellow-400 mb-10 rounded-full"></div>
              <h2 className="text-5xl md:text-8xl font-black text-blue-900 mb-10 tracking-tighter leading-[0.9]">Meet Your <br/><span className="text-slate-200 uppercase tracking-widest text-4xl block mt-4 font-black">Expert Guide</span></h2>
              <p className="text-slate-600 text-2xl mb-10 leading-relaxed font-medium">
                Professionalism is not an act, it's a habit. I bring years of certified training to every passenger I serve at Entebbe.
              </p>
              <div className="space-y-8 mb-16">
                <div className="flex items-center gap-8 p-6 rounded-[2.5rem] bg-slate-50 border border-slate-100 hover:shadow-xl transition-all cursor-default group">
                  <div className="w-16 h-16 bg-blue-900 rounded-2xl flex items-center justify-center text-3xl text-white group-hover:rotate-12 transition-transform shadow-lg">🛂</div>
                  <div>
                    <h4 className="font-black text-blue-900 text-lg">VIP Handling</h4>
                    <p className="text-slate-400 text-sm font-medium">Navigating VIP and standard protocols with ease.</p>
                  </div>
                </div>
                <div className="flex items-center gap-8 p-6 rounded-[2.5rem] bg-yellow-50 border border-yellow-100 hover:shadow-xl transition-all cursor-default group">
                  <div className="w-16 h-16 bg-yellow-400 rounded-2xl flex items-center justify-center text-3xl text-blue-900 group-hover:-rotate-12 transition-transform shadow-lg">✈️</div>
                  <div>
                    <h4 className="font-black text-blue-900 text-lg">Aviation Mastery</h4>
                    <p className="text-slate-400 text-sm font-medium">Comprehensive understanding of Skywings standards.</p>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-12 border-t border-slate-100 pt-12">
                <button 
                  onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-blue-900 text-white font-black px-12 py-6 rounded-[2rem] hover:bg-blue-800 transition-all active:scale-95 shadow-2xl flex items-center gap-3"
                >
                  Work With Me
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-40 bg-slate-50 relative overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="text-center mb-24 reveal opacity-0 translate-y-10 transition-all duration-1000">
            <h2 className="text-5xl md:text-8xl font-black text-blue-900 mb-8 tracking-tighter leading-[1]">Support Packages</h2>
            <p className="text-slate-400 max-w-2xl mx-auto text-2xl font-medium leading-relaxed">
              Transparent pricing. Direct Mobile Money (MOMO) payments.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
            <div className="lg:col-span-8 space-y-10">
              <div className="flex justify-between items-end mb-12">
                <div>
                  <h3 className="text-3xl font-black text-blue-900 tracking-tight">Available Support</h3>
                  <div className="w-12 h-1.5 bg-yellow-400 rounded-full mt-2"></div>
                </div>
                <div className="bg-white p-2.5 rounded-[2rem] flex shadow-xl border border-slate-100">
                  <button onClick={() => setCurrency('USD')} className={`px-10 py-4 rounded-[1.5rem] text-sm font-black transition-all ${currency === 'USD' ? 'bg-blue-900 text-white shadow-2xl' : 'text-slate-400 hover:text-slate-600'}`}>USD</button>
                  <button onClick={() => setCurrency('UGX')} className={`px-10 py-4 rounded-[1.5rem] text-sm font-black transition-all ${currency === 'UGX' ? 'bg-blue-900 text-white shadow-2xl' : 'text-slate-400 hover:text-slate-600'}`}>UGX</button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                {SERVICES.map((service) => (
                  <div 
                    key={service.id}
                    onClick={() => toggleService(service.id)}
                    className={`relative overflow-hidden p-12 rounded-[4rem] border-4 transition-all cursor-pointer group flex flex-col justify-between h-full ${
                      selectedServices.includes(service.id) 
                        ? 'bg-blue-900 border-blue-900 text-white shadow-[0_40px_80px_rgba(30,58,138,0.3)]' 
                        : 'bg-white border-white hover:border-blue-100 hover:shadow-2xl shadow-lg'
                    }`}
                  >
                    <div>
                      <div className="flex justify-between items-start mb-12">
                        <div className={`w-24 h-24 rounded-[2.5rem] flex items-center justify-center text-5xl transition-all duration-500 shadow-inner ${
                          selectedServices.includes(service.id) ? 'bg-white/20 scale-110' : 'bg-slate-100 group-hover:scale-110'
                        }`}>
                          {service.icon}
                        </div>
                        <button 
                          onClick={(e) => triggerAssistant(e, service.title)}
                          className={`p-4 rounded-2xl text-xs font-black uppercase tracking-widest transition-all shadow-sm ${
                            selectedServices.includes(service.id) ? 'bg-white/10 text-white hover:bg-white/20' : 'bg-blue-50 text-blue-900 hover:bg-blue-100'
                          }`}
                        >
                          Details
                        </button>
                      </div>
                      <h4 className={`text-3xl font-black mb-4 tracking-tight ${selectedServices.includes(service.id) ? 'text-white' : 'text-blue-900'}`}>
                        {service.title}
                      </h4>
                      <p className={`text-lg leading-relaxed mb-10 font-medium ${selectedServices.includes(service.id) ? 'text-blue-100' : 'text-slate-400'}`}>
                        {service.description}
                      </p>
                    </div>

                    <div className="flex items-center justify-between mt-auto pt-10 border-t border-white/10">
                      <p className={`text-4xl font-black tracking-tighter ${selectedServices.includes(service.id) ? 'text-yellow-400' : 'text-blue-900'}`}>
                        {currency === 'USD' ? '$' : ''}
                        {(currency === 'USD' ? service.priceUSD : service.priceUSD * EXCHANGE_RATE).toLocaleString()}
                        <span className="text-lg ml-1 font-bold">{currency === 'UGX' ? ' /=' : ''}</span>
                      </p>
                      <div className={`w-12 h-12 rounded-full border-4 flex items-center justify-center transition-all shadow-sm ${
                        selectedServices.includes(service.id) ? 'bg-yellow-400 border-yellow-400' : 'border-slate-100'
                      }`}>
                        {selectedServices.includes(service.id) && (
                          <svg className="w-8 h-8 text-blue-900" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/>
                          </svg>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Billing Summary Panel - Interactive Quote */}
            <div className="lg:col-span-4">
              <div className={`bg-white rounded-[5rem] shadow-[0_80px_160px_rgba(0,0,0,0.1)] p-14 border border-slate-100 sticky top-32 transition-all duration-500 ${shouldPulse ? 'pulse-select' : ''}`}>
                <div className="flex items-center gap-5 mb-12 border-b border-slate-50 pb-10">
                  <div className="w-16 h-16 bg-blue-900 rounded-[1.5rem] flex items-center justify-center text-white font-black text-2xl shadow-xl">Q</div>
                  <h3 className="text-3xl font-black text-blue-900 tracking-tighter">Instant Quote</h3>
                </div>
                
                <div className="space-y-8 mb-14">
                  {selectedServices.length === 0 ? (
                    <div className="py-20 px-10 text-center border-4 border-dashed border-slate-50 rounded-[4rem]">
                      <p className="text-slate-300 text-sm font-black uppercase tracking-widest leading-relaxed">
                        Start your selection <br/> to generate pricing
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {selectedServices.map(id => {
                        const s = SERVICES.find(item => item.id === id);
                        return (
                          <div key={id} className="flex justify-between items-center animate-fadeIn group">
                            <span className="text-slate-600 font-bold text-lg group-hover:text-blue-900 transition-colors">{s?.title}</span>
                            <span className="text-blue-900 font-black text-xl">
                              {currency === 'USD' ? '$' : ''}
                              {(currency === 'USD' ? s?.priceUSD : (s?.priceUSD || 0) * EXCHANGE_RATE).toLocaleString()}
                            </span>
                          </div>
                        );
                      })}
                      
                      <div className="border-t border-slate-100 pt-8 mt-10 space-y-6">
                        <div className="flex justify-between items-center text-xs text-slate-400 font-black uppercase tracking-[0.2em]">
                          <span>Net Subtotal</span>
                          <span>{currency === 'USD' ? '$' : ''}{billingData.subtotal.toLocaleString()}</span>
                        </div>
                        
                        {billingData.discount > 0 && (
                          <div className="flex justify-between items-center text-lg text-green-600 font-black bg-green-50/50 px-8 py-6 rounded-[2.5rem] border-2 border-green-100/50 shadow-inner">
                            <div className="flex flex-col">
                              <span className="text-xs uppercase tracking-widest opacity-60">Bundle Saving</span>
                              <span>{billingData.bundleName}</span>
                            </div>
                            <span>-{currency === 'USD' ? '$' : ''}{billingData.discount.toLocaleString()}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                <div className="bg-blue-900 rounded-[3rem] p-12 mb-14 text-white shadow-[0_30px_60px_rgba(30,58,138,0.4)] relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-125 transition-transform duration-1000"></div>
                  <div className="flex flex-col relative z-10">
                    <span className="font-black text-xs uppercase tracking-[0.4em] opacity-40 mb-4">Final Total</span>
                    <span className="text-6xl font-black text-yellow-400 tracking-tighter">
                      {currency === 'USD' ? '$' : ''}
                      {billingData.total.toLocaleString()}
                      <span className="text-2xl ml-2 font-medium">{currency === 'UGX' ? '/=' : ''}</span>
                    </span>
                  </div>
                </div>

                <div className="space-y-10">
                  <div className="relative p-10 rounded-[3rem] border-4 border-blue-900 bg-white text-blue-900 shadow-2xl transition-all flex flex-col items-center gap-6 group cursor-pointer hover:bg-slate-50" onClick={copyToClipboard}>
                    <span className="text-6xl group-hover:scale-125 transition-transform duration-500 group-hover:rotate-12">📱</span>
                    <span className="text-base font-black uppercase tracking-[0.3em]">Direct MOMO</span>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest text-center leading-tight">Click to Copy Phone Number</p>
                    {copyStatus && <div className="absolute inset-0 bg-blue-900/98 flex flex-col items-center justify-center rounded-[2.6rem] text-white animate-fadeIn">
                      <span className="text-3xl mb-2">📋</span>
                      <span className="font-black uppercase tracking-widest">Number Copied!</span>
                    </div>}
                  </div>

                  <button 
                    onClick={handleConfirmSelection}
                    disabled={selectedServices.length === 0}
                    className={`w-full font-black py-8 rounded-[2.5rem] transition-all shadow-[0_20px_40px_rgba(0,0,0,0.1)] text-2xl transform active:scale-95 flex items-center justify-center gap-4 ${
                      isConfirmed ? 'bg-green-500 text-white' : 'bg-yellow-400 hover:bg-yellow-500 text-blue-900'
                    }`}
                  >
                    {isConfirmed ? 'Selection Logged' : 'Finalize Selection'}
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M13 7l5 5m0 0l-5 5m5-5H6"/></svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-40 bg-white overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="text-center mb-24 reveal opacity-0 translate-y-10 transition-all duration-1000">
            <h2 className="text-5xl md:text-8xl font-black text-blue-900 mb-8 tracking-tighter">Client Reviews</h2>
            <p className="text-slate-400 text-2xl font-medium max-w-xl mx-auto">Real stories from the PEARL of Africa.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="bg-slate-50 p-14 rounded-[5rem] border border-slate-100 reveal opacity-0 translate-y-10 transition-all duration-1000 group hover:bg-blue-900 hover:text-white hover:shadow-3xl transition-all duration-700" style={{ transitionDelay: `${i * 200}ms` }}>
                <div className="flex text-yellow-400 mb-10 group-hover:scale-110 transition-transform">
                  {[...Array(t.rating)].map((_, j) => (
                    <svg key={j} className="w-8 h-8 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                  ))}
                </div>
                <p className="text-2xl font-bold leading-[1.4] italic mb-12 opacity-90">"{t.text}"</p>
                <div className="flex items-center gap-6">
                  <div className="w-20 h-20 bg-blue-900 group-hover:bg-yellow-400 rounded-[2rem] flex items-center justify-center text-white group-hover:text-blue-900 font-black text-2xl transition-all duration-500 shadow-xl">{t.author.charAt(0)}</div>
                  <h4 className="font-black uppercase tracking-[0.3em] text-xs">{t.author}</h4>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Optional Contact Section - WhatsApp Hero */}
      <section id="contact" className="py-40 bg-blue-900 relative">
        <div className="container mx-auto px-6">
          <div className="bg-white/5 backdrop-blur-3xl rounded-[6rem] border border-white/10 p-14 md:p-32 flex flex-col lg:flex-row gap-32 reveal opacity-0 translate-y-10 transition-all duration-1000">
            <div className="w-full lg:w-1/2 text-white">
              <span className="text-yellow-400 font-black uppercase tracking-[0.5em] text-xs mb-8 block">Final Steps</span>
              <h2 className="text-6xl md:text-9xl font-black mb-14 leading-[0.8] tracking-tighter">
                Complete <br/> Your <span className="text-yellow-400">Order.</span>
              </h2>
              <div className="inline-block mb-12 text-blue-300 text-xs font-black uppercase tracking-[0.3em] bg-blue-800/80 backdrop-blur-3xl px-8 py-4 rounded-3xl border border-blue-600 shadow-inner">
                (Optional Step)
              </div>
              <p className="text-blue-100 text-2xl mb-16 opacity-70 leading-relaxed max-w-lg font-medium">
                Submit your details for a record or jump straight to WhatsApp for live flight coordination.
              </p>
              
              <div className="space-y-8">
                 <a 
                   href="https://wa.me/256709733284"
                   target="_blank"
                   rel="noopener noreferrer"
                   className="flex items-start gap-8 p-10 bg-white/5 rounded-[3.5rem] border-2 border-white/10 group hover:bg-white/10 transition-all duration-500 cursor-pointer block hover:border-yellow-400/50"
                 >
                   <div className="w-20 h-20 bg-yellow-400 rounded-3xl flex items-center justify-center text-blue-900 text-4xl shrink-0 group-hover:rotate-12 transition-transform duration-500 shadow-2xl">💬</div>
                   <div>
                     <p className="font-black text-2xl mb-3 text-white group-hover:text-yellow-400 transition-colors">Chat Live with Cedric</p>
                     <p className="text-base text-blue-200 opacity-60 leading-relaxed font-medium">Coordinate arrival times, flight numbers, and direct support via WhatsApp.</p>
                   </div>
                 </a>
              </div>
            </div>

            <div className="w-full lg:w-1/2 bg-white rounded-[5rem] p-12 md:p-24 shadow-[0_60px_120px_rgba(0,0,0,0.3)] relative">
              {!user && (
                <div className="absolute inset-0 bg-white/95 backdrop-blur-2xl z-10 flex flex-col items-center justify-center p-16 text-center rounded-[5rem]">
                  <p className="text-blue-900 font-black text-3xl mb-10 tracking-tighter">Sign In to <br/> Secure Your Visit</p>
                  <button onClick={() => setShowAuth(true)} className="bg-blue-900 text-white font-black px-16 py-7 rounded-[2rem] shadow-2xl hover:bg-blue-800 transition-all transform active:scale-95 text-xl">
                    Open Profile
                  </button>
                </div>
              )}
              <form action="https://formspree.io/f/maylkwqd" method="POST" onSubmit={handleFormSubmit} className="space-y-12">
                <div>
                  <label className="block text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] mb-5 ml-6">Booking Identity</label>
                  <input type="email" name="email" value={user?.email || ''} readOnly className="w-full bg-slate-50 border-none rounded-[2rem] px-10 py-7 focus:outline-none font-black text-slate-500 cursor-not-allowed text-lg"/>
                </div>
                <div>
                  <label className="block text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] mb-5 ml-6">Special Instructions (Optional)</label>
                  <textarea name="message" rows={6} placeholder="Arrival time, airline, or specific assistance requests..." className="w-full bg-slate-50 border-none rounded-[3rem] px-10 py-8 focus:outline-none focus:ring-8 focus:ring-blue-50 transition-all resize-none font-bold text-lg placeholder:opacity-40"></textarea>
                </div>
                
                <div className="flex flex-col gap-8">
                  <button 
                    type="submit" 
                    disabled={formStatus === 'loading'}
                    className={`w-full text-blue-900 font-black py-8 rounded-[2.5rem] transition-all shadow-2xl transform active:scale-95 text-2xl ${
                      formStatus === 'loading' ? 'bg-blue-100 animate-pulse' : 
                      formStatus === 'success' ? 'bg-green-400 text-white' : 'bg-yellow-400 hover:bg-yellow-500'
                    }`}
                  >
                    {formStatus === 'loading' ? 'Submitting...' : formStatus === 'success' ? '✓ Booking Noted' : 'Submit Form'}
                  </button>
                  
                  <div className="flex items-center gap-8 py-4">
                    <div className="h-0.5 bg-slate-100 flex-1"></div>
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.5em]">Express</span>
                    <div className="h-0.5 bg-slate-100 flex-1"></div>
                  </div>

                  <a 
                    href="https://wa.me/256709733284"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-green-500 hover:bg-green-600 text-white font-black py-8 rounded-[2.5rem] transition-all shadow-2xl flex items-center justify-center gap-5 transform active:scale-95 text-xl group"
                  >
                    <svg className="w-10 h-10 group-hover:scale-125 transition-transform" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.72.94 3.659 1.437 5.63 1.438h.004c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                    WhatsApp Chat
                  </a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>

      <footer className="py-40 bg-slate-50 text-center">
        <button onClick={scrollToTop} className="w-24 h-24 bg-blue-900 rounded-[2.5rem] flex items-center justify-center font-black text-white text-5xl mx-auto mb-12 shadow-3xl hover:scale-110 transition-transform active:scale-90">C</button>
        <p className="text-blue-900 font-black tracking-[0.5em] text-[10px] uppercase mb-6 opacity-30">&copy; 2026 Cedric Travel & Airport Assistance</p>
        <p className="text-slate-400 font-bold text-lg">Entebbe International Airport, Uganda.</p>
        <button onClick={scrollToTop} className="mt-12 text-blue-900 font-black text-xs uppercase tracking-[0.4em] hover:text-yellow-500 transition-colors border-b-2 border-transparent hover:border-yellow-400 pb-1">Back to Clouds ↑</button>
      </footer>

      <Assistant />
      
      <a href="https://wa.me/256709733284" target="_blank" rel="noopener noreferrer" className="fixed bottom-12 right-12 z-50 w-24 h-24 bg-green-500 rounded-full shadow-[0_30px_60px_rgba(34,197,94,0.5)] flex items-center justify-center animate-bounce [animation-duration:5s] hover:scale-110 transition-transform group">
        <svg className="w-14 h-14 text-white group-hover:rotate-12 transition-transform" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.72.94 3.659 1.437 5.63 1.438h.004c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
      </a>
    </div>
  );
};

export default App;
