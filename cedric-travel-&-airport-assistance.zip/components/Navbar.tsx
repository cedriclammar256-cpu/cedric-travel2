
import React, { useState, useEffect } from 'react';
import { User } from '../types';

interface NavbarProps {
  user: User | null;
  onAuthClick: () => void;
  onLogout: () => void;
  onLogoClick?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, onAuthClick, onLogout, onLogoClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      // Background shift
      setIsScrolled(window.scrollY > 20);

      // ScrollSpy logic
      const sections = ['about', 'services', 'testimonials', 'contact'];
      const scrollPosition = window.scrollY + 120; // Offset for better detection

      let current = '';
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element && scrollPosition >= element.offsetTop) {
          current = section;
        }
      }
      setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Initial check
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about', id: 'about' },
    { name: 'Services', href: '#services', id: 'services' },
    { name: 'Testimonials', href: '#testimonials', id: 'testimonials' },
    { name: 'Contact', href: '#contact', id: 'contact' },
  ];

  const handleLogoClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onLogoClick) onLogoClick();
    else window.scrollTo({ top: 0, behavior: 'smooth' });
    setIsMobileMenuOpen(false);
  };

  const handleLinkClick = (e: React.MouseEvent, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${isScrolled ? 'bg-blue-900 shadow-xl py-3' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <div className="flex items-center gap-3 cursor-pointer group" onClick={handleLogoClick}>
          <div className="w-12 h-12 bg-yellow-400 rounded-2xl flex items-center justify-center font-black text-blue-900 text-2xl group-hover:scale-110 transition-transform group-hover:rotate-6 shadow-lg">C</div>
          <h1 className="text-white font-black text-xl hidden lg:block tracking-tighter">Cedric Travel</h1>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-10">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              onClick={(e) => handleLinkClick(e, link.href)}
              className={`text-sm font-black uppercase tracking-[0.2em] transition-all relative py-2 ${
                activeSection === link.id 
                ? 'text-yellow-400 opacity-100' 
                : 'text-white opacity-60 hover:opacity-100 hover:text-yellow-200'
              }`}
            >
              {link.name}
              {activeSection === link.id && (
                <span className="absolute -bottom-1 left-0 w-full h-1 bg-yellow-400 rounded-full animate-pulse" />
              )}
            </a>
          ))}
          
          <div className="h-6 w-px bg-white/10 ml-2" />
          
          {user ? (
            <div className="flex items-center gap-5">
              <span className="text-white text-xs font-black uppercase tracking-widest flex items-center gap-3 bg-white/10 px-4 py-2 rounded-full border border-white/10">
                <div className="w-6 h-6 rounded-lg bg-yellow-400 flex items-center justify-center text-[10px] text-blue-900">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                {user.name}
              </span>
              <button 
                onClick={onLogout}
                className="text-[10px] font-black uppercase tracking-[0.3em] text-white/40 hover:text-yellow-400 transition-colors"
              >
                Logout
              </button>
            </div>
          ) : (
            <button 
              onClick={onAuthClick}
              className="bg-yellow-400 hover:bg-yellow-500 text-blue-900 font-black px-8 py-3 rounded-2xl transition-all text-xs uppercase tracking-widest active:scale-95 shadow-lg"
            >
              Login Profile
            </button>
          )}
        </div>

        {/* Mobile Toggle */}
        <div className="md:hidden flex items-center gap-4">
          {!user && (
            <button 
              onClick={onAuthClick}
              className="bg-yellow-400 text-blue-900 font-black px-4 py-2 rounded-xl text-[10px] uppercase tracking-widest"
            >
              Login
            </button>
          )}
          <button 
            className="text-white text-3xl p-2 focus:outline-none"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? '✕' : '☰'}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-blue-900/98 backdrop-blur-2xl absolute top-0 left-0 w-full h-screen p-12 flex flex-col justify-center items-center gap-10 animate-fadeIn z-[60]">
          <button className="absolute top-8 right-8 text-white text-4xl" onClick={() => setIsMobileMenuOpen(false)}>✕</button>
          
          <div className="flex items-center gap-3 mb-10">
            <div className="w-16 h-16 bg-yellow-400 rounded-3xl flex items-center justify-center font-black text-blue-900 text-3xl">C</div>
          </div>

          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              onClick={(e) => handleLinkClick(e, link.href)}
              className={`text-3xl font-black uppercase tracking-widest transition-all ${
                activeSection === link.id ? 'text-yellow-400 scale-110' : 'text-white opacity-50'
              }`}
            >
              {link.name}
            </a>
          ))}
          
          <div className="w-full h-px bg-white/10 my-4" />
          
          {user ? (
            <div className="flex flex-col items-center gap-4">
              <span className="text-white text-lg font-black">{user.name}</span>
              <button 
                onClick={() => { onLogout(); setIsMobileMenuOpen(false); }}
                className="text-yellow-400 font-black uppercase tracking-[0.2em] text-sm"
              >
                Logout Account
              </button>
            </div>
          ) : (
            <button 
              onClick={() => { onAuthClick(); setIsMobileMenuOpen(false); }}
              className="bg-yellow-400 text-blue-900 font-black px-12 py-5 rounded-3xl text-lg uppercase tracking-widest"
            >
              Login Now
            </button>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
