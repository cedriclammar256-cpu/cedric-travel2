
import React, { useState } from 'react';
import { User } from '../types';

interface AuthProps {
  onLogin: (user: User) => void;
  onClose: () => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin, onClose }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const userData: User = {
        name: isLogin ? (email.split('@')[0]) : name,
        email: email,
        isLoggedIn: true
      };
      
      localStorage.setItem('cedric_user', JSON.stringify(userData));
      onLogin(userData);
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-6">
      <div 
        className="absolute inset-0 bg-blue-900/40 backdrop-blur-md" 
        onClick={onClose}
      />
      
      <div className="relative w-full max-w-md bg-white rounded-[3rem] shadow-2xl overflow-hidden animate-fadeInUp">
        <div className="bg-blue-900 p-10 text-center text-white relative">
          <div className="absolute top-6 right-8 cursor-pointer text-white/50 hover:text-white transition-colors" onClick={onClose}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
          </div>
          <div className="w-16 h-16 bg-yellow-400 rounded-2xl flex items-center justify-center font-bold text-blue-900 text-3xl mx-auto mb-6 shadow-xl">C</div>
          <h2 className="text-3xl font-black tracking-tight">{isLogin ? 'Welcome Back' : 'Join the Journey'}</h2>
          <p className="text-blue-200 text-sm mt-2 opacity-80">
            {isLogin ? 'Access your Entebbe travel profile' : 'Start your seamless travel experience'}
          </p>
        </div>

        <div className="p-10">
          <form onSubmit={handleSubmit} className="space-y-6">
            {!isLogin && (
              <div className="animate-fadeIn">
                <label className="block text-slate-400 text-[10px] font-black uppercase tracking-widest mb-2 ml-2">Full Name</label>
                <input 
                  type="text" 
                  required 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Cedric Musani" 
                  className="w-full bg-slate-50 border-none rounded-2xl px-6 py-4 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all font-medium"
                />
              </div>
            )}
            
            <div>
              <label className="block text-slate-400 text-[10px] font-black uppercase tracking-widest mb-2 ml-2">Email Address</label>
              <input 
                type="email" 
                required 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="traveler@example.com" 
                className="w-full bg-slate-50 border-none rounded-2xl px-6 py-4 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all font-medium"
              />
            </div>
            
            <div>
              <label className="block text-slate-400 text-[10px] font-black uppercase tracking-widest mb-2 ml-2">Password</label>
              <input 
                type="password" 
                required 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••" 
                className="w-full bg-slate-50 border-none rounded-2xl px-6 py-4 focus:outline-none focus:ring-4 focus:ring-blue-100 transition-all font-medium"
              />
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-blue-900 text-white font-black py-5 rounded-2xl hover:bg-blue-800 transition-all shadow-xl active:scale-95 flex items-center justify-center gap-3"
            >
              {loading ? (
                <>
                  <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                  Processing...
                </>
              ) : (
                isLogin ? 'Login Now' : 'Create Account'
              )}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="text-sm font-bold text-blue-900 hover:text-blue-700 transition-colors"
            >
              {isLogin ? "Don't have an account? Sign up" : "Already have an account? Log in"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;
